setTimeout(function() {
    console.log('Fire event!');
}, 3000);

while(1) {}
