module.exports = {
    name: 'StemOS',
    desc: 'JavaScript OS',
    url: 'http://stem.mandice.org/',
    supports: [
        'JavaScript',
        'Node.js',
        'HTML5'
    ]
};
