module.exports = function() {
    console.log('Hello Module!');
};
