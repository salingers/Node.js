var hello_module = require('./hello_module');

hello_module();
