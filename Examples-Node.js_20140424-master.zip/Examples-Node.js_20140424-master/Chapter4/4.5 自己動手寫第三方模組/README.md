demo-hello-module
=================

Hello module by Mandice Contributors.

Features
-

* Print hello world.

Installation
-

Install directly via NPM

    npm install hello_world

Getting started
-

Write a file call app.js and require the module.

___`<project directory>`/app.js:___
```js
var hello_module = require('./lib/hello_module');

hello_module();
```

***

### Run the app.js

    node app.js


License
-
Licensed under the MIT License

Authors
-
Copyright(c) 2013 Mandice Contributors <<example@mandice.com>>