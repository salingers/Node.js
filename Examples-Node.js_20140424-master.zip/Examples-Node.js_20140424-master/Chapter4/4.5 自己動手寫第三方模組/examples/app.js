var hello_module = require('../lib/hello_module.js');

hello_module();
