class MockModel
end
