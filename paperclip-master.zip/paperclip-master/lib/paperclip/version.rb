module Paperclip
  VERSION = "4.2.0" unless defined? Paperclip::VERSION
end
