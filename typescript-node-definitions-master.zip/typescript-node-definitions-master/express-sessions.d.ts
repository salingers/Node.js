declare module "express3" {
    interface Request {
        session: any;
    }
}