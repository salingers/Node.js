var App = SC.Application.create({
  isInitialised: false
});

App.ToolbarController = SC.Object.create({
  map: null,
  zoom: 6,
  searchQueryBinding: '*map.searchQuery',

  scale: function() {
    this.set('zoom', this.getPath('map.zoom'));
  },

  search: function() {
    this.get('map').search();
  }
});

App.ToolbarView = SC.View.extend({
  classNames: ['toolbar'],
  templateName: 'toolbar',
  contentBinding: 'App.ToolbarController',

  mouseEnter: function() {
    SC.run.cancel(this._timeout);
    this.$('.toolbar-content').fadeIn();
  },

  mouseLeave: function() {
    SC.run.cancel(this._timeout);
    this._timeout = SC.run.later(this, '_hideContent', 500);
  },

  flashContent: function() {
    SC.run.cancel(this._timeout);
    this.$('.toolbar-content').fadeIn();
    this._timeout = SC.run.later(this, '_hideContent', 500);
  }.observes('content.map'),

  _hideContent: function() {
    this.$('.toolbar-content').fadeOut();
  }
});

App.SearchField = SC.TextField.extend({
  insertNewline: function() {
    this.getPath('parentView.content').search();
  }
});

App.MapView = SC.ContainerView.extend(SB.ManagedLayoutSupport, {
  classNames: ['map'],
  searchQuery: '',
  toolbarBinding: 'App.ToolbarController',

  didInsertElement: function() {
    this._super();
    this.$().goMap({
      scaleControl: true,
      navigationControl: true,
      navigationControlOptions: {
        position: 'TOP_LEFT',
        style: 'ZOOM_PAN'
      }
    });

    this.set('map', this.$().data('goMap'));

    if (!App.isInitialised) {
      App.isInitialised = true;
      this.mouseEnter();
    }
  },

  mouseEnter: function() {
    this.setPath('toolbar.map', this);

    $('.toolbar').position({
      my: 'center top',
      at: 'center top',
      of: this.$()
    });
  },

  zoom: function(key, value) {
    if (value !== undefined) {
      this.map.setMap({zoom:value});
    }
    return this.getPath('map.map.zoom');
  }.property(),

  search: function() {
    this.map.setMap({address:this.get('searchQuery')});
  },

  zoomDidChange: function() {
    var zoom = this.getPath('toolbar.zoom');
    if (this.get('state') === 'inDOM' && this.get('zoom') !== zoom) {
      this.set('zoom', zoom);
    }
  }.observes('toolbar.zoom'),

  applyLayout: function(width, height) {
    this.$().width((width / 2) - 5).height((height / 2) - 5);
  }
});
