Mirror-Maps
===========

This very simple appliquation was requested by my girlfriend :) She is Architect / Urban planner and works alot with google maps. She wanted to to have four maps side by side and be able to synchronise level of zoom in different views.

http://mirror-maps.heroku.com

