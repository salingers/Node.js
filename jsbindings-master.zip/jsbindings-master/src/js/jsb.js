//
// Javascript Bindigns helper file
//

// DO NOT ALTER THE ORDER
require('jsb_cocos2d.js');
require('jsb_chipmunk.js');
require('jsb_opengl.js');
require('jsb_cocosbuilder.js');
require('jsb_sys.js');
