#!/bin/sh
#
# run this script from the CocosDenshion directory. eg:
# cd ~/src/cocos2d-iphone/CocosDenshion/CocosDenshion
#
../../external/JavaScript/jsbindings/generate_complement.py -o ../../external/JavaScript/jsbindings/configs/CocosDenshion/CocosDenshion-complement.txt *.h

