#!/bin/sh
#
# run this script from the cocosBuilderReader directory. eg:
# cd ~/src/cocos2d-iphone/externals/CocosBuilderReader/
#
../../../external/JavaScript/jsbindings/generate_complement.py -o ../../../external/JavaScript/jsbindings/configs/CocosBuilderReader/CocosBuilderReader-complement.txt *.h

