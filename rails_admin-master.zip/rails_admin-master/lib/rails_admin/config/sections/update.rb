require 'rails_admin/config/sections/edit'

module RailsAdmin
  module Config
    module Sections
      class Update < RailsAdmin::Config::Sections::Edit
      end
    end
  end
end
