# Be sure to restart your server when you modify this file.

DummyApp::Application.config.session_store :cookie_store, key: '_dummy_app_session'
