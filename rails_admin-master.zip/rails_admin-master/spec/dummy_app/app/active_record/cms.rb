module Cms
  def self.table_name_prefix
    'cms_'
  end
end
