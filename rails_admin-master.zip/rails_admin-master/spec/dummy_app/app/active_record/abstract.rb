class Abstract < ActiveRecord::Base
  self.abstract_class = true
end
