class PaperTrailTest < ActiveRecord::Base
  has_paper_trail
end
