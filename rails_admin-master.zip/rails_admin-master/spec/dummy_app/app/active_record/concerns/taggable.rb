module Taggable
  extend ActiveSupport::Concern
  # dummy
end
