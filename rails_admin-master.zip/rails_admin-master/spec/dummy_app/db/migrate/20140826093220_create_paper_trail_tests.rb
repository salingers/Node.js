class CreatePaperTrailTests < ActiveRecord::Migration
  def change
    create_table :paper_trail_tests do |t|
      t.string :name

      t.timestamps
    end
  end
end
