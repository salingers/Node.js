===============
The Django Book
===============

This book was originally published by Apress in 2009 and covered Django version 1.0. Since then it has languished and, in places, is **extremely out of date**. It's here mostly for historical purposes. If you'd like to take it over and update it, contact me: ``jacob at jacobian dot org``.
