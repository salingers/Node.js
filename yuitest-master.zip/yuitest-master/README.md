YUITest JavaScript Testing Library
==================================

Building
--------

To build JavaScript files, run this in the javascript directory:

    ant all
    
Building an NPM package
-----------------------

To build an npm package (output to javascript/build/yuitest/npm), run this in the javascript directory:

    ant npmbuild
    
    
Build Status
------------

[![Build Status](https://secure.travis-ci.org/yui/yuitest.png?branch=master)](http://travis-ci.org/yui/yuitest)
