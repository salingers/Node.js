function test(){

    if(o)
        for(var prop in o)
            doSomething();


    for(var x=initX;x<str_arr.length;x++)
         str_arr[x]=str_arr[x].charAt(0).toUpperCase()+str_arr[x].substring(1);


}