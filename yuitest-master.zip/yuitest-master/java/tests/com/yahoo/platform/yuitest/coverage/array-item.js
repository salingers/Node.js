var foo = [

    hello

];