var foo = {
    
    "test": function(){
        alert("hello");
    },
    
    foo: function(){
        alert("goodbye");
    },
    
    'bar': function(){
        alert("Woohoo");
    }

};