testloop:
while (true){
    doSomething();
}