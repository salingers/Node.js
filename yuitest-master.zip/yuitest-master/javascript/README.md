YUI Test Framework
------------------

Documentation: http://yuilibrary.com/yuitest


Currently undergoing a "Dav transformation" :)
