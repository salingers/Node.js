var duck = require('./duck');
var Bird = require('./bird');

duck.say();

var bird = new Bird();

bird.say();