/**
 *
 * @type  array
 */
module.exports = ['danhuang', 'jimi', 'teley'];