/**
 *
 * @class Observer
 */
 
 module.exports = function(){
	this.update = function(){
		console.log('base observer');
	}
 }