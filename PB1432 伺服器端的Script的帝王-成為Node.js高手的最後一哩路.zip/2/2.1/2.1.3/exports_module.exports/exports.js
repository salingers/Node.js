exports.name = "aa";
exports.happy = function(){console.log("mm")};
console.log(module.exports);