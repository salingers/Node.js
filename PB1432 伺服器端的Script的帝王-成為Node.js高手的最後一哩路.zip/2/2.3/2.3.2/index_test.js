var Student = require('./student');
var student = new Student();
student.study();
