var student = require('./student_static');
student.study();
student.eat();
student.sleep();