/* target.js */
module.exports = function(){
	this.request = function(){
		console.log('Target::request');
	}
}