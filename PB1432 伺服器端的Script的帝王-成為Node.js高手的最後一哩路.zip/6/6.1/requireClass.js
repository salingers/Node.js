var Class  = require('./class');
var object = require('./object');
console.log('*******is a class*******');
var classObj = new Class();
classObj.show();
console.log('*******is a object*******');
object.show();

