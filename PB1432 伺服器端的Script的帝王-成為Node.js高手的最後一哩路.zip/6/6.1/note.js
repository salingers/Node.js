/**
 * @type class Note
 * @author danhuang
 * @time 2012-12-17
 * @desc desc note.js
 *
 */
 module.exports = function(){
	this.show = function(){
		console.log('this is a note test');
	}
 }