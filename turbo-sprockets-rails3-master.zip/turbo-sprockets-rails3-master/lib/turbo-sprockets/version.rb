module TurboSprockets
  VERSION = "0.3.14"
end
