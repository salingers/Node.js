var hello = require('./build/Release/hello.node');

console.log(hello.sayHello());
