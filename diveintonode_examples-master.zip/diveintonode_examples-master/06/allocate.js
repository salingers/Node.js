var buf = new Buffer(100);
