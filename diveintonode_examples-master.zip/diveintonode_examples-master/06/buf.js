var buf = new Buffer('床前明月光，疑是地上霜；举头望明月，低头思故乡。', 'utf-8');
console.log(buf);
console.log(buf.length);
