# Instructions

Before importing the Flash Builder project please perform the following steps:

 1. Copy/paste `benchmark.js` into the `src` folder.
 2. Copy/paste `AIRIntrospector.js` from some place like `C:\Program Files\Adobe\Adobe Flash Builder 4.5\sdks\4.5.0\frameworks\libs\air\AIRIntrospector.js` into the `src` folder.
