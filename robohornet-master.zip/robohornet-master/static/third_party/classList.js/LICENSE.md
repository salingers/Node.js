This software is dedicated to the public domain. No warranty is expressed or implied.
Use this software at your own risk.
