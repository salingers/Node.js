classList.js is a cross-browser JavaScript shim that fully implements `element.classList`. Refer to [the MDN page on `element.classList`][1] for more information.


![Tracking image](//in.getclicky.com/212712ns.gif)


  [1]: https://developer.mozilla.org/en/DOM/element.classList "MDN / DOM / element.classList"
